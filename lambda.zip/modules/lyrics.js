module.exports = "P.P.A.P. ...  I have a pen.  I have a apple.  Ahhh, apple pen.  ... I have a pen.  I have pineapple.  Ahhh, pineapple pen.  ...  Apple pennn!  Pineapple pennn!  Ahhh.  Pen pineapple apple pen.  Pen pineapple apple pen.  Dance Time!";

// Credit: Pico Taro (https://www.youtube.com/watch?v=HFlgNoUsr4k)
